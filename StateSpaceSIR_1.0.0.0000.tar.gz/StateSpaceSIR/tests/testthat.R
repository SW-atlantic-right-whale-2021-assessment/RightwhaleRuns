library(testthat)
library(StateSpaceSIR)

test_check("StateSpaceSIR")
